function swichpage(page) {
    const contentSection = document.getElementById('content');
    switch (page) {
        case 'upgrades':
            document.getElementById("items").style.display = 'none';
            document.getElementById("upgrades").style.display = 'block';
            break;
        case 'items':
            document.getElementById("items").style.display = 'block';
            document.getElementById("upgrades").style.display = 'none';
            break;
        default:
            contentSection.innerHTML = '<p>none</p>';
    }
}

let cursorAmount = 0,
    clickGain = 1,
    clickmulti = 1,
    newItemPriceNum = 10,
    itemPrices = [15],
    itemGain = [0.125],
    upgradeinfo = {
        'stronger fingers': {
            'price': 100,
            'type': '11',
            'gain1': ['*', 1.5, 'full'],
            'gain2': ['+', 1],
        },
        'good mouse': {
            'price': 150,
            'type': 'click',
            'gain1': ['*', 2, 'partal'],
        },
        'tape on mouse': {
            'price': 300,
            'type': '01',
            'gain1': ['*', 2, 'full'],
            'gain2': ['+', 1],
        },
        'template': {
            'price': 100,
            'type': '11',/* 11 is cilck and persec and the only time you use gain 2 01 is click and 10 is persec*/
            'gain1': ['*', 1.5, ''/* enter full or partal while using '*' */],
            'gain2': ['+', 1],
        },
        'template': {
            'price': 100,
            'type': '11',
            'gain1': ['*', 1.5, ''],
            'gain2': ['+', 1],
        },
    },
    newUpgradePriceNum = 60,
    upgradePrices = [],
    perSec = 0;

const repeatCode = (times, code) => Array.from({ length: times }, () => code());

function generateItemPrices(amount) {
    for (let i = 1; i <= amount; i++) {
        newItemPriceNum *= 10 + i % 2 + (1 < i % 3);
        itemGain.push(Math.round((newItemPriceNum * i * 2) / (i * 1.5) / 100));
        itemPrices.push(newItemPriceNum);
    }
}

function generateUpgradePrices(amount) {
    for (let i = 1; i <= amount; i++) {
        newUpgradePriceNum *= (1.5 + (i % 2 + (1 < i % 3) / 2) / (1 + (i / (amount / (2000 * i)))));
        upgradePrices.push(Math.round(newUpgradePriceNum));
    }
}

function hover(id) {
    document.getElementById("pricetxt").textContent = `Price: ${itemPrices[id]}`;
    document.getElementById("gaintxt").textContent = `Gain: ${itemGain[id]}`;
}

function unhover() {
    document.getElementById("pricetxt").textContent = "Price:";
    document.getElementById("gaintxt").textContent = "Gain:";
}

function buyitem(id) {
    let personalPrice = itemPrices[id];
    let personalGain = itemGain[id];

    if (cursorAmount >= personalPrice) {
        cursorAmount -= personalPrice;
        perSec += personalGain;
        itemPrices[id] = Math.ceil(itemPrices[id] * 1.15);
        hover(id);
    }
}

function cursorclick() {
    cursorAmount += (clickGain * clickmulti);
}

function update() {
    function updateCursorText() {
        document.getElementById("cursorsamounttxt").textContent = Math.round(cursorAmount);
    }

    function secGain() {
        cursorAmount += perSec / 127.5;
    }

    setInterval(secGain, 1);
    setInterval(updateCursorText, 1);
}

generateItemPrices(20);
generateUpgradePrices(400);
console.log(" " + upgradePrices);
update();
